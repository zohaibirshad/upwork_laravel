Please Signup to portal using following Link

http://127.0.0.1:8000/api/sign-up<?php /**PATH E:\xampp\htdocs\laravel_test\resources\views/mail.blade.php ENDPATH**/ ?>