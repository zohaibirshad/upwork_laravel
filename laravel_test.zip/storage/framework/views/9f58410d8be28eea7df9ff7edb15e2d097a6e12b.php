Hi

Verification Pin <?php echo e($pin); ?><?php /**PATH E:\xampp\htdocs\laravel_test\resources\views/pin.blade.php ENDPATH**/ ?>