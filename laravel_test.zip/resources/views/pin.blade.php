Hi

Verification Pin {{ $pin }}